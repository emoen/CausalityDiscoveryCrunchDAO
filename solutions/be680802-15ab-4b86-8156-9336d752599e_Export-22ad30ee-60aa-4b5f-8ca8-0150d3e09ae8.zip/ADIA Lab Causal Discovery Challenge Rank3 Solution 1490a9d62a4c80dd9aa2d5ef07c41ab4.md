# ADIA Lab Causal Discovery Challenge Rank3 Solution

# Introduction

## Links

- **Chinese version Solution:**
    
    [中文版 Chinese Version](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/%E4%B8%AD%E6%96%87%E7%89%88%20Chinese%20Version%201490a9d62a4c81009852c866196549c6.md)
    
- **Competition Link:**
    
     [CrunchDAO Causality Discovery Competition](https://hub.crunchdao.com/competitions/causality-discovery)
    
- **Code Repository:**
    
     [GitHub: ADIA-Lab-Causal-Discovery](https://github.com/Ori-Replication/ADIA-Lab-Causal-Discovery)
    

## Acknowledgements

First and foremost, we would like to express our heartfelt gratitude to CrunchDAO and ADIA Lab for organizing this competition. Our sincere thanks go to all the staff involved for their hard work in creating such an exciting and challenging event. Additionally, I would like to thank my university, ShanghaiTech, for promoting this competition and my two classmates for informing me about it. Their kindness and support enabled me to participate in this competition.

This solution was a collaborative effort by **Mutian Hong** from ShanghaiTech University and **Guoqin Gu** from Xiamen University.

We achieved balanced accuracy of **73.43%** on the public leaderboard and **74.06%** in the out-of-sample stage. 

Contract Us:

- Mutian
    - Linkedin: https://www.linkedin.com/in/%E6%B2%90%E5%A4%A9-%E6%B4%AA-329545337/?trk=opento_sprofile_topcard
    - E-mail: hongmt2022@shanghaitech.edu.cn
- Guoqin
    - Linkedin: http://www.linkedin.com/in/guoqin-gu-32b7922a2
    - E-mail: guoqin_gu@163.com
- Feel free to ask us question about this solution! 😊

# Solution

## Problem Statement and Analysis

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image.png)

In this competition, our objective was to identify causal relationships. Specifically, given a causal graph with a known relationship X→Y, where X and Y are two nodes, the graph contains additional nodes named as numbers from 0 to 9. These nodes might play different roles in the causal relationship between X and Y. For instance, in the diagram above, node 1 is a common cause of X and Y, node 0 is their common effect, while node 2 is independent of both X and Y.

The organizers provided observational data generated from causal graphs following specific rules. The left side of the diagram above shows an example of 1,000 observations. The task was framed as a classification problem to determine the type of relationship between other nodes (v) and X, Y—for example, whether v→X. If this edge exists, the label is 1; otherwise, it is 0.

Upon further analysis, there are three possible relationships between v and X: v→X, X→v, or independence. Similarly, there are three possibilities for v and Y. Combining these, we arrive at 9 possible relationships. However, one configuration (Y→v→X) is impossible due to the acyclic nature of causal graphs. Hence, we defined this as an **8-class classification problem** with the following categories:

| Role | Relationship |
| --- | --- |
| Confounder | X←v→Y |
| Collider | X→v←Y |
| Mediator | X→v→Y |
| Cause of X | v→X |
| Cause of Y | v→Y |
| Effect of X | X→v |
| Effect of Y | Y→v |
| Independent | v |

## TLDR

Our solution primarily relied on extensive **feature engineering** combined with a **boosted tree model** for supervised training. We built upon the framework provided in the official `supervised_baseline` code.

Most of our efforts were directed towards designing effective features. These include correlation-based features, information-theoretic features, discretization-based statistical features, regression coefficients, unsupervised causal discovery outputs, statistical test results, structural equation modeling outputs, and more. Detailed descriptions of these features can be found in the [Feature Engineering - Correlation Features](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/%E4%B8%AD%E6%96%87%E7%89%88%20Chinese%20Version%201490a9d62a4c81009852c866196549c6.md) section below.

During the competition, we iteratively validated the effectiveness of features through exploratory data analysis (EDA), literature review, Python library exploration, online searches, and discussions with generative AI tools. New features were generated using these methods, added to the dataset, and tested using models to observe their impact on performance. Initially, we used Random Forest for rapid iterations. Once we reached a plateau in performance, we transitioned to LGBM for further evaluations. Features that improved performance were retained, while those causing deterioration were discarded. Additionally, data augmentation significantly enhanced our score.

For the final submission, we explored several model ensemble strategies. Ultimately, we submitted an ensemble of three **XGBoost** models, each with 7,000, 7,500, and 8,000 estimators, respectively (other hyperparameters were the same). We chose these estimator counts considering the larger evaluation dataset for the private leaderboard. Locally, the optimal number was 7,000.

## Detailed Steps

### Exploratory Data Analysis (EDA)

EDA revealed several critical insights. For example, the data contained different dimensions (3–10), meaning there were 1–8 additional variables apart from X and Y. The distribution of final labels varied significantly across dimensions, as shown below:

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%201.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%201.png)

The number of causal relationships also differed by dimension:

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%202.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%202.png)

We examined the rules used to generate data and found intriguing patterns. For example, in a 3-variable causal graph:

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%203.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%203.png)

Sorting observations by the value of variable 0 produced the following pattern:

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%204.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%204.png)

This revealed a perfect correlation between 0 and Y, with all three lines converging after the 800th observation. Such insights highlighted potential issues with matrix inversion when perfect correlations existed.

For higher dimensions, similar patterns and noise were observed:

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%205.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%205.png)

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%206.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%206.png)

### Data Augmentation

In our previous analysis, we observed that causal graphs often contain multiple causal relationships. Here, we focus on the relationships between other variables and X, Y. Given the presence of these other causal relationships, could we designate other variables (numeric ones) as new X and Y? The answer is yes. In fact, the causal graph seems to follow a consistent set of generation rules, with no inherent special significance to the existing X and Y. For instance, we can transform the original causal graph as follows:

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/d9a9b16f247d29f0aed71e804d58264a_720.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/d9a9b16f247d29f0aed71e804d58264a_720.png)

Here, we simply remapped the variable names while keeping the causal graph itself unchanged. This effectively provides the model with new data. It may be hard to explain intuitively why this approach works, but it can be better understood when tied to feature engineering.

For example, when calculating the Pearson correlation coefficients, we compute corr(v,X)\text{corr}(v, X), corr(v,Y)\text{corr}(v, Y), and corr(X,Y)\text{corr}(X, Y). These three features are then fed into the model for training. By redefining X and Y based on other causal relationships, we effectively generate new datasets that allow the model to classify new pairs of X and Y.

This method allows data augmentation of up to approximately 11.21 times (based on an average of 11.21 causal relationships per graph). In our final implementation, we enhanced nearly all local datasets, resulting in a performance improvement of about 5%.

### Feature Engineering: Multi-threaded Computation

Each feature engineering function operates on a single dataset. To speed up the process, we iterated through each feature engineering function and processed datasets in parallel, finally combining the features into a single DataFrame.

On our 128-core server, applying feature engineering to 23,000 datasets (augmented to approximately 260,000 datasets) took around 20 hours.

As shown below, each observation dataset (including augmented datasets) was transformed into a DataFrame containing the dataset ID, variable names, a series of features, and the target.

For simplicity, we use the term **variables** to refer to all variables in an observation dataset except X and Y. We denote an individual variable by v, and all other variables besides v as **others**.

![ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/184a5ebfb4a9eff7c24896f711dabbd.jpg](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/184a5ebfb4a9eff7c24896f711dabbd.jpg)

---

### Feature Engineering: Correlation Features

1. **Pearson Correlation Coefficient**
    - ***Func* corr**: Provides the absolute value of the Pearson correlation coefficient between two variables.
    - Features: corr(v, X)、corr(v, Y)、max(corr(v, others))、min(corr(v, others))、mean(corr(v, others))、std(corr(v, others))、25%(corr(v, others))、75%(corr(v, others))、corr(X, Y)。
2. **Rolling Correlation Coefficient**
    - ***Func* abs_rolling_corr**: Computes a series of absolute Pearson correlation coefficients using a rolling window of size 300.
    - Features: max(abs_rolling_corr(v, X))、min(abs_rolling_corr(v, X))、mean(abs_rolling_corr(v, X))、max(abs_rolling_corr(v, Y))、min(abs_rolling_corr(v, Y))、mean(abs_rolling_corr(v, Y))。
3. **Spearman Correlation Coefficient**
    - ***Func* spearman_corr**: Provides the absolute value of the Spearman correlation coefficient.
    - Features similar to those for Pearson.
4. **Kendall Correlation Coefficient**
    - ***Func* kendall_corr**: Provides the absolute value of the Kendall correlation coefficient.
    - Features similar to those for Pearson.
5. **Distance Correlation Coefficient:** A nice feature with about **1 point** imporvement.
    - ***Func* dcor**: Provides the distance correlation coefficient.
    
    > Reference: https://github.com/vnmabus/dcor
    > 
    - Features: dcor(v, X)、dcor(v, Y)、dcor(v, X)^2、dcor(v, Y)^2、max(dcor(v, others))、min(dcor(v, others))、mean(dcor(v, others))、std(dcor(v, others))、25%(dcor(v, others))、75%(dcor(v, others))、dcor(X, Y)、dcor(X, Y)^2。
6. **Partial Correlation Coefficient**
    - ***Func* partial_corr**: Computes the partial correlation coefficient between two variables given a third variable.
    - Features: partial_corr(v, X|Y)、partial_corr(v, Y|X)、partial_corr(X, Y|v)。

---

### Feature Engineering: Information-Theoretic Features

1. **Mutual Information**
    - ***Func* MI**: Measures the mutual information between two variables
        - The definition of mutual information for discrete variables:
            
            $$
            I(X; Y) = \sum_{x \in X} \sum_{y \in Y} p(x, y) \log \frac{p(x, y)}{p(x)p(y)}
            $$
            
        - Mutual information derived from entropy:
            
            $$
            I(X; Y) = H(X) - H(X|Y) = H(Y) - H(Y|X) = H(X) + H(Y) - H(X, Y)
            $$
            
        - We use the convenient tools provided by sklearn for computation:
            
            ```python
            from sklearn.feature_selection import mutual_info_regression
            tmp = mutual_info_regression(dataset.drop(columns=[variable]), dataset[variable])
            ```
            
    - Features：MI(v, X)、MI(v, Y)、max(MI(v, others))、min(MI(v, others))、mean(MI(v, others))、std(MI(v, others))、MI(X, Y)。
2. **Conditional Mutual Information**
    - ***Func* Conditional_MI**: Measures the conditional mutual information between two variables given a third.
        - Conditional mutual information derived from entropy:
            
            $$
            I(X; Y | Z) = H(X,Z) + H(Y,Z) - H(X,Y,Z) - H(Z) = H(X | Z) - H(X|Y,Z) = H(X | Z) + H(Y | Z) - H(X, Y | Z)
            $$
            
        - We can use Venn diagrams to represent mutual information and conditional mutual information, hoping to illustrate them more intuitively.
            
            ![4e50458a5c9d10ffa6fe53c0c556073.jpg](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/4e50458a5c9d10ffa6fe53c0c556073.jpg)
            
        - Conditional mutual information derived from mutual information:
            
            $$
            I(X; Y | Z) = I(X;Y,Z) - I(X;Z)
            $$
            
        - we use sklearn:
            
            ```python
            # Calculate conditional MI(v, X | Y)
            mi_vx_given_y = mutual_info_regression(dataset[[variable, "Y"]], dataset["X"], discrete_features=False)[0] - \
                            mutual_info_regression(dataset[["Y"]], dataset["X"], discrete_features=False)[0]
                           
            ```
            
    - Features:  conditional_MI(v,X|Y)、conditional_MI(v,Y|X)、conditional_MI(X,Y|v).
3. **Copula Entropy**
    - ***Func* copula_entropy**: Captures the statistical dependency between two random variables.
    
    > Reference: https://github.com/majianthu/pycopent
    > 
    - Features：copula_entropy(v,X)、copula_entropy(v,Y)

---

### Feature Engineering: Discretization-Based Features

> For Features 1-3, the original variables after discretization are input; for Features 4-7, the normalized discrete variables are input.
> 

> Reference: https://github.com/diogo149/CauseEffectPairsChallenge
> 
1. **Information Metrics**
    - JH(v,x): The joint entropy $H(v, x)$ of variable *v* and *X*.
    - JH(v,y): The joint entropy $H(v, y)$ of variable *v* and *Y*.
    - CH(v|x): The conditional entropy $H(v|x)$ of variable *v* given *X*.
    - CH(v|y): The conditional entropy $H(v|y)$ of variable *v* given *Y*.
2. **Mutual Information Metrics**
    - I(v,x): The mutual information $I(v; x)$ between variable *v* and *X*.
    - I(v,y): The mutual information $I(v; y)$ between variable *v* and *Y*.
    - AMI(v,x): The adjusted mutual information $AMI(v; x)$ between variable *v* and *X*.
    - AMI(v,y): The adjusted mutual information $AMI(v; y)$ between variable *v* and *Y*.
3. **Error Probability Metrics**
    - NPE(v,x): The normalized prediction error between variable *v* and *X*.
    - NPE(v,y): The normalized prediction error between variable *v* and *Y*.
4. **Information-Geometric Causal Inference (IGCI) Metrics**
    - IGCI(v,x): The IGCI metric based on *v* and *X*.
    - IGCI(v,y): The IGCI metric based on *v* and *Y*.
    - IGCI(x,v): The IGCI metric based on *X* and *v*.
    - IGCI(y,v): The IGCI metric based on *Y* and *v*.
5. **Moment Features**
    - MM(v² * x): The normalized joint moment $I(v^2 * x)$.
    - MM(v² * y): The normalized joint moment $I(v^2 * y)$.
    - MM(v² * x²): The normalized joint moment $I(v^2 * x^2)$.
    - MM(v² * y²): The normalized joint moment $I(v^2 * y^2)$.
    - MM(v³ * x): The normalized joint moment $I(v^3 * x)$.
    - MM(v³ * y): The normalized joint moment $I(v^3 * y)$.
6. **Fit Metrics**
    - fit(v,x): The fit metric based on *v* and *X*, calculated via polynomial fitting.
    - fit(v,y): The fit metric based on *v* and *Y*, calculated via polynomial fitting.
    - fit_error(v,x): The fit error based on *v* and *X*, measured by the standard deviation of residuals after polynomial fitting.
    - fit_error(v,y): The fit error based on *v* and *Y*, measured by the standard deviation of residuals after polynomial fitting.
    - fit_noise_entropy(v,x): The noise entropy after fitting, measuring the information content of noise for *v* and *X*.
    - fit_noise_entropy(v,y): The noise entropy after fitting, measuring the information content of noise for *v* and *Y*.
    - fit_noise_skewness(v,x): The standard deviation of noise skewness, measuring asymmetry in the noise distribution for *v* and *X*.
    - fit_noise_skewness(v,y): The standard deviation of noise skewness, measuring asymmetry in the noise distribution for *v* and *Y*.
    - fit_noise_kurtosis(v,x): The standard deviation of noise kurtosis, measuring the peakedness of the noise distribution for *v* and *X*.
    - fit_noise_kurtosis(v,y): The standard deviation of noise kurtosis, measuring the peakedness of the noise distribution for *v* and *Y*.
7. **Conditional Distribution Similarity**
    - cond_dist_sim(v,x): The conditional distribution similarity of variable *v* relative to *X*.
    - cond_dist_sim(v,y): The conditional distribution similarity of variable *v* relative to *Y*.

---

### Feature Engineering: Regression Coefficients

1. **Linear Regression:** Linear models are simple yet effective. By improving the linear model, we achieved a gain of **seven points**.
    - ***Func* *linear_regression_feature***
        - `model1`： $Fit ~~ X, v, v^2, v * v_{others}, v * X, cos(v), sin(v) \sim Y$
            
            ```python
            model1_features = ["X"] + variables
            d1 = Squared_term(dataset[model1_features], model1_features)
            d1 = Interaction_term(d1, model1_features)
            d1 = Cos_Sin_term(d1, variables)
            model1_features = d1.columns.tolist()
            d1_scaled = scaler.fit_transform(d1)
            model1 = LinearRegression().fit(d1_scaled, dataset[["Y"]])
            model1_coefs = model1.coef_[0].tolist()
            model1_dict = {name: coef for name, coef in zip(model1_features, model1_coefs)}
            ```
            
        - Features: v~Y_coef, v_squared~Y_coef, v*X~Y_coef, v_cos~Y_coef, v_sin~Y_coef, X~Y_coef.
        - `model2`： $Fit ~~ v, v^2, v*v_{others}, cos(v), sin(v) \sim X$
            
            ```python
            model2_features = variables
            d2 = Squared_term(dataset[model2_features], model2_features)
            d2 = Interaction_term(d2, model2_features)
            d2 = Cos_Sin_term(d2, variables)
            model2_features = d2.columns.tolist()
            d2_scaled = scaler.fit_transform(d2)
            model2 = LinearRegression().fit(d2_scaled, dataset[["X"]])
            model2_coefs = model2.coef_[0].tolist()
            model2_dict = {name: coef for name, coef in zip(model2_features, model2_coefs)}
            ```
            
        - Features: v~X_coef, v_squared~X_coef, v_cos~X_coef, v_sin~X_coef.
        - `model3`： $Fit ~~ v_{others}, X, X^2, cos(X), sin(X), Y, Y^2, cos(Y), sin(Y)， X*Y \sim v$
            
            ```python
            for i, variable in enumerate(variables):
                model3_features = ["X", "Y"] + dataset.columns.drop(["X", "Y", variable]).tolist()
                d3 = Squared_term(dataset[model3_features], model3_features)
                d3 = Interaction_term(d3, model3_features)
                d3 = Cos_Sin_term(d3, model3_features)
                model3_features = d3.columns.tolist()
                d3_scaled = scaler.fit_transform(d3)
                model3 = LinearRegression().fit(d3_scaled, dataset[[variable]])
                model3_coefs = model3.coef_[0].tolist()
                model3_dict = {name: coef for name, coef in zip(model3_features, model3_coefs)}
            ```
            
        - Features：X~v_coef、X_squared~v_coef、X_cos~v_coef、X_sin~v_coef、Y~v_coef、Y_squared~v_coef、Y_cos~v_coef、Y_sin~v_coef、X*Y~v_coef.
2. **Ridge Regression**
    - ***Func ridge_regression_feature:*** Ridge regression introduced a penalty term, and we used `GridSearchCV` to select an appropriate alpha value from `np.logspace(-6, 6, 13)`. The results are shown in the figure.
        
        ![image.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%207.png)
        
    - Similar to linear models `model1` and `model2`, which perform regression on *Y* and *X*, respectively*.*
    - Features:  v~Y_ridge_coef, X~Y_ridge_coef, v~X_ridge_coef.
3. **Piecewise Linear Regression**
    - Splits data into segments based on percentiles or thresholds, performing regression within each segment.
4. **Piecewise Quadratic Regression**
    - Extends piecewise linear regression by incorporating quadratic terms.

### Feature Engineering - Causal Discovery Features

1. **ExactSearch based on BIC score**: nice approach, we gain more than **6 points** from it!
    - ***Func ExactSearch_feature:***
        
        > Reference: [Exact Search — causal-learn 0.1.3.6 documentation](https://causal-learn.readthedocs.io/en/latest/search_methods_index/Score-based%20causal%20discovery%20methods/ExactSearch.html)
        > 
        - Searches for possible causal structures to find an optimal causal graph based on the data. Uses **BIC** as the model scoring criterion.
        - ExactSearch generates its predicted causal graph. When generating features, we create binary features. For example, if ExactSearch predicts v → X, then ExactSearch(v,X) = 1, else 0
    - Features: ExactSearch(v,X), ExactSearch(X,v), ExactSearch(v,Y), ExactSearch(Y,v), ExactSearch(X,Y). We tried including more information like *ExactSearch(v,others,X)*, but it was ineffective.
2. **PC Algorithm**
    - ***Func PC_feature:***
        
        > Reference: https://causal-learn.readthedocs.io/en/latest/search_methods_index/Constraint-based%20causal%20discovery%20methods/PC.html
        > 
        - The PC algorithm is a constraint-based causal discovery method that constructs causal graphs through conditional independence tests. We generated binary features similar to ExactSearch, such as PC(v,X), PC(X,v), PC(v,Y), PC(Y,v), PC(X,Y). These features reflect the causal relationships inferred by the algorithm, providing additional structured information for our model.
    - Features: PC(v,X), PC(X,v), PC(v,Y), PC(Y,v), PC(X,Y)
3. **FCI (Fast Causal Inference) Algorithm**
    - ***Func FCI_feature:***
        - FCI algorithm is an extended version of the PC algorithm, capable of handling latent variables (although we don't have any here) and selection bias. It infers causal relationships through a series of independence tests and generates a Partial Ancestral Graph (PAG).
    - Features: FCI(v,X), FCI(X,v), FCI(v,Y), FCI(Y,v), FCI(X,Y).
4. **GRaSP (Greedy Relaxation and Selection of Parents)**
    - ***Func GRaSP_feature:***
        
        > Reference: [GRaSP — causal-learn 0.1.3.6 documentation](https://causal-learn.readthedocs.io/en/latest/search_methods_index/Permutation-based%20causal%20discovery%20methods/GRaSP.html#grasp)
        > 
        - Identifies causal structure and outputs an Ancestral Graph.
        - For the generated ancestral graph, we still use encoding methods similar to the above approaches.
    - Features: GRaSP(v,X), GRaSP(X,v), GRaSP(v,Y), GRaSP(Y,v), GRaSP(X,Y)
5. **DML (Double Machine Learning)**: about **2 points** improvement (not that good as we expected) with high importance in booth xgb & lgb
    - ***Func DML_feature:***
        
        > Reference: [econml.dml.DML — econml 0.15.1 documentation](https://econml.azurewebsites.net/_autosummary/econml.dml.DML.html)
        > 
        - Double Machine Learning (DML) is a method for causal inference that estimates causal effects by eliminating confounding bias. DML uses machine learning models to estimate potential confounding variables, thereby improving the accuracy and robustness of causal effect estimation. The algorithm utilizes causal forests as estimators.
        - We generated a series of features using the DML method, based on causal effect estimates for different variable pairs. Specifically, for variable pairs v and X, and v and Y, we estimated AMTE (Average Marginal Treatment Effect) and its statistics, such as z-statistics, p-values, standard deviation, and standard error.
    - Features: v~X_DML_AMTE, v~Y_DML_AMTE, X~v_DML_AMTE, Y~v_DML_AMTE, etc.

### Feature Engineering - Others

1. **PPS (Predictive Power Score)**
    - ***Func PPS:***
        - Used to measure the predictive relationship between two variables. PPS is an asymmetric measurement tool that focuses on predictive effectiveness rather than simple linear or statistical correlation, compared to traditional correlation analysis (like Pearson correlation coefficient). PPS calculation is based on machine learning model performance: evaluating the relationship strength between variables by assessing how well X predicts target variable Y.
        
        > Reference: https://github.com/8080labs/ppscore
        > 
    - Features: PPS(v,X), PPS(X,v), PPS(v,Y), PPS(Y,v), PPS(X,Y), max(PPS(v,others)), mean(PPS(v,others))
2. **Dimension Information**
    - ***Func add_dimension_feature:*** The causal graphs in the problem have different dimensions, with different label proportions across dimensions, and significant differences in various properties of causal graphs, which is an important feature for the model.
    - Features: dimension, square_dimension
3. **Grid Information**
    - ***Func grid:*** Since all data is between [-1.0, 1.0], after sorting by X or Y, divide the interval equally into 25 grids and count the number of data points in each grid.
    - Features: grid(v,X)(0,0) ~ grid(v,X)(4,4), grid(v,Y)(0,0) ~ grid(v,Y)(4,4)
4. **SEM (Structural Equation Model)**
    - ***Func sem_features:***
        - We use a special modeling approach: we limit our research scope to X, Y, and v variables (without other v's), then model seven relationships excluding Independent from the eight relationships mentioned above. For example:
        
        ```python
        model_templates = {
            "Confounder": """
                X ~ a1*v
                Y ~ b1*X + b2*v
                X ~~ X
                v ~~ v
                Y ~~ Y
            """,... }
        
        ```
        
        - Then, we calculate the AIC, BIC, CFI, TLI, and RMESA scores for the model.
5. **Cloud**
    
    > Reference: Masatoshi, Kobayashi., Kohei, Miyaguchi., Shin, Matsushima. (2022) Detection of Unobserved Common Cause in Discrete Data Based on the MDL Principle
    > 
    - ***Func Cloud**:* Can provide causal relationships between binary variables.
    - Features: Cloud(v,X), Cloud(v,Y), Cloud(X,Y). We slightly modified the source code so that Cloud(v,X) and Cloud(v,Y) determine the causal direction between variables, while Cloud(X,Y) determines whether there exists a confounder between variables.

### Model Training and Ensemble

- Variables with fewer than 10 unique values were set as categorical variables.
    
    ```python
    def process_categorical_features(df, max_unique=10):
        """
        Identifies and processes categorical variables in the DataFrame.
    
        Parameters:
        - df (pd.DataFrame): The input DataFrame.
        - max_unique (int): Maximum number of unique values to classify a column as categorical.
    
        Returns:
        - cat_idxs (list of int): Indices of the categorical features.
        - cat_dims (list of int): Number of unique values (modes) for each categorical feature.
        - df (pd.DataFrame): The encoded DataFrame.
        """
        cat_cols = [col for col in df.columns if df[col].nunique() <= max_unique]
        cat_dims = []
        cat_idxs = []
    
        for col in cat_cols:
            if col == 'augment':
                continue
            print(f"     ->->-> Processing categorical feature: {col}, Number of unique values: {df[col].nunique()}")
            # Use LabelEncoder
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str).fillna('NaN'))
            cat_dims.append(len(le.classes_))
            cat_idxs.append(df.columns.get_loc(col))
    
        return cat_idxs, cat_dims, df
    ```
    
- We initially tried a weighted soft voting ensemble of LGB, CAT, XGB, and HistBoost, but it did not perform well. In the end, we opted for an ensemble of 3 XGB models, differing only in the number of estimators and random seeds.
    
    ```python
    early_stop = xgb.callback.EarlyStopping(
            rounds=20, save_best=True, maximize=False, metric_name='mlogloss'
        )
    xgb_model = XGBClassifier(
        n_estimators=7000 / 7500 / 8000,
        learning_rate=0.05,
        objective='multi:softmax',
        num_class=8,
        eval_metric='mlogloss',
    
        max_depth=6,
        subsample=0.7,
        colsample_bytree=0.7,
        min_child_weight=1,
        gamma=0.3,
        reg_lambda=18.0,
        reg_alpha=18.0,
        tree_method='gpu_hist', 
        max_delta_step=0.5,
        
        verbosity=0,
        use_label_encoder=False,
        random_state=42 / 77 / 2,
        callbacks=[early_stop]
    )
    xgb_model.fit(
        X_train, y_train,
        sample_weight=sample_weights,
        eval_set=[(X_train, y_train)],
        verbose=100
    )
    ```
    
- During tuning, we performed test set splits(10%) for validation. For the final submission, we trained on the entire dataset—hoping for a miracle (just kidding).
- To save time on submission, we used a trick to only process the data that not appeared in the training set. In this competition, this is a special case. we will have additional training data in the submission phase. We uploaded the processed local data and also a json file, which included the keys that appeared in the training set. So that in the processing in the final run, it will only process the test data. In the test phase, we don’t have time to process the whole 9400 additional augmented data(11.21x), we only did a 7x augmentation here.

### Feature importance analysis

XGBoost

![image.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%208.png)

LGBM

![image.png](ADIA%20Lab%20Causal%20Discovery%20Challenge%20Rank3%20Solution%201490a9d62a4c80dd9aa2d5ef07c41ab4/image%209.png)

### Failed attempts

- Remove outliers from certain features
- LGBM/ LassoCV DML
- ttest
- conditional independence tests
- Pillai test
- entropy features
- MIC
- multi mutual information
- ANM (too slow)
- HSIC
- segmented ridge regression
- arcsin fetaure in linear regression
- cluster features
- …

### Closing Remarks

- by mutian
    - The threads of causality weave our story. In our childhood, we were neighbors and playmates, sharing the sunshine and gentle breeze of our hometown. As time flowed, we each ventured far, only to meet again under the sky of data science. This was not merely a coincidence of probability and statistics, but rather seemed like a foreshadowing laid down by destiny. From childhood laughter to our current exploration of causal inference, our life trajectories resemble an intricate causal model: causality and destiny intertwined, culminating in our reunion. Now, in this competition of causal inference, we are not only exploring the connections behind data but also witnessing the wonderful causal chains in our own lives.
    - In machine learning, models can get stuck in local optima, and humans are the same - sometimes we continuously optimize within our comfort zone and become stagnant. Fortunately, I wasn't alone in this data science competition. When I was wandering in the maze of thoughts, you were always there to lend a helping hand, pulling me out of the valley of local optima. This tacit understanding of supporting and inspiring each other is the most touching power of a data science team.
    - Thanks my best teammate Guoqin!
- by guoqin
    - This is the second time teaming up with Mutian. We’ve known each other for a long time (like, *from childhood*, lol). I’m really happy that we can still collaborate across opposite ends of the globe (US & China) and achieve great results in such a competitive challenge.
    - Causal inference is absolutely fascinating. It was a joy to continuously learn, understand, and apply knowledge throughout the competition. I hope to conduct some exciting research in this field in the future.
    - Thanks to ADIA Lab, CrunchDAO, and Mutian!